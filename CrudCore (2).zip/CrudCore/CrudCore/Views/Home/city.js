﻿var app = angulare.module("myApp");
app.run(function ($rootScope) {
    $rootScope.url = "http://localhost:7400";
})

app.controller("ctlCity", function ($scope) {

    $scop.get = function () {
        var _obj = {};
        _obj.CityName = $scope.CityName;

        $http({
            method: 'Post',
            data: JSON.stringify( _obj),
            dataType: 'json',
            url: $rootScope.api + '/Home/getCity'
        }).then(function (response) {

            if (response.data != null)
                $scope.citys = response.data;
            });
    }

})