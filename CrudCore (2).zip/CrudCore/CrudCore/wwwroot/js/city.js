﻿var app = angular.module("myApp",[]);

app.run(function ($rootScope) {
    $rootScope.api = "http://localhost:14067";
})
     
app.controller("ctlCity", function ($scope, $http, $rootScope) {
      $scope.citys = [];
      $scope.CityName = '';

    $scope.get = function () {
        var _obj = {};
        _obj.CityName = $scope.CityName;
        _obj.CityID = 0;

        $http({
            method: "post",
            datatype: "JSON",
            data: JSON.stringify(_obj),
            url: $rootScope.api + '/Home/getCity'
        }).then(function (response) {

            if (response.data != null)
                $scope.citys = response.data;
            });
    }
    $scope.getCitybyID = function () {
        var _obj = {};
        _obj.CityName = $scope.CityName;
 
        $http({
            method: "post",
            datatype: "JSON",
            data: JSON.stringify(_obj),
            url: $rootScope.api + '/Home/getCitybyID'
        }).then(function (response) {

            if (response.data != null)
                $scope.citys = response.data;
            });
    }

})