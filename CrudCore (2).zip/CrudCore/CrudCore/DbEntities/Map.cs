﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudCore.DbEntities
{
    public class StateMap
    {
        public StateMap(EntityTypeBuilder<tbl_State> entityBuilder)
        {
            entityBuilder.HasKey(t => t.StateID);
            entityBuilder.Property(t => t.StateName).IsRequired();
        }
    }
}
