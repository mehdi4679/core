﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace CrudCore.DbEntities
{
    public class CRUDContext : DbContext
    {
        public CRUDContext(DbContextOptions<CRUDContext> options) : base(options)
        {

        }
        public DbSet<tbl_State> tbl_state{get;set;}
        public DbSet<tbl_city> tbl_Citys { get; set; }
            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);
                new StateMap(modelBuilder.Entity<tbl_State>());
            }
        }
 }
