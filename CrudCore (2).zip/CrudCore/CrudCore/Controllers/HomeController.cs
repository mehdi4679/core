﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CrudCore.DbEntities;
using System.IO;
using Microsoft.AspNetCore.Http;
using OfficeOpenXml;


namespace CrudCore.Controllers
{
    public class HomeController : Controller
    {
        private CRUDContext context;

        public HomeController(CRUDContext _c)
        {
            context = _c;
        }
        [HttpPost]
        public JsonResult Get()
        {
            IEnumerable<tbl_State> models = context.tbl_state.ToList();
            return Json(models);//, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public JsonResult getCity(tbl_city model)
        {
 
            var list = (from _c in context.tbl_Citys
                        join _s in context.tbl_state on _c.StateID equals _s.StateID
                        //where _c.CityName == ((model.CityName == "" || model.CityName == null) ? _c.CityName : model.CityName)
                        select new { _c.CityName, _c.CityID, _c.StateID, _s.StateName }).Take(10);
            return Json(list);
        }
        [HttpPost]
        public JsonResult getCitybyID(tbl_city model)
        {
            var list = (from _c in context.tbl_Citys
                        join _s in context.tbl_state on _c.StateID equals _s.StateID
                         where _c.CityName == ((model.CityName == "" || model.CityName == null) ? _c.CityName : model.CityName)
                        select new { _c.CityName, _c.CityID, _c.StateID, _s.StateName }).Take(10);
            return Json(list);
        }


        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {

            if (file == null || file.Length == 0)
                return Content("file not selected");

            string fileExtension = Path.GetExtension(file.FileName);
            if (fileExtension != ".xls" && fileExtension != ".xlsx")
                return Content("");

            var path = Path.Combine(
                        Directory.GetCurrentDirectory(), "wwwroot",
                        file.FileName);

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }
            FileInfo fileexel = new FileInfo(path);

            using (ExcelPackage package = new ExcelPackage(fileexel))
            {
                // get first worksheet 
                ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//.Add("Employee");
                int rowCount = worksheet.Dimension.Rows;
                int colCount = worksheet.Dimension.Columns;
                List<tbl_State> listState = new List<tbl_State>();
                List<tbl_city> listCity = new List<tbl_city>();
                listCity = context.tbl_Citys.ToList();
                listState = context.tbl_state.ToList();

                for (int row = 1; row <= rowCount; row++)
                {
                    for (int col = 1; col <= colCount; col++)
                    {
                        tbl_State _obj = new tbl_State();
                        _obj.StateName = worksheet.Cells[row, 1].Value.ToString();
                        if (col == 1)
                        {
                            if (listState.Where(_x => _x.StateName == _obj.StateName).Count() == 0)
                            {
                                await context.tbl_state.AddAsync(_obj);
                                await context.SaveChangesAsync();
                                listState.Add(_obj);
                            }
                        }
                        else if (col == 2)
                        {
                            tbl_city _objcity = new tbl_city();
                            _objcity.CityName = worksheet.Cells[row, col].Value.ToString();
                            if (listCity.Where(_x => _x.CityName == _objcity.CityName).Count() == 0)
                            {
                                _objcity.StateID = listState.Where(_x => _x.StateName == _obj.StateName).Select(_x => _x.StateID).FirstOrDefault();

                                listCity.Add(_objcity);
                                await context.tbl_Citys.AddAsync(_objcity);
                            }
                        }
                    }
                }
                await context.SaveChangesAsync();
             }
            ViewData["message"] = "file uploaded";
            return View(); 
        }

        [HttpGet]
        public IActionResult UploadFile()
        {
            ViewData["message"] = "جستجو در فایل";

            return View();
        }
        [HttpPost]
 
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
