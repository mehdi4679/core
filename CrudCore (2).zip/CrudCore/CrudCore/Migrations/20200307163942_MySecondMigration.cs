﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CrudCore.Migrations
{
    public partial class MySecondMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_State",
                table: "tbl_State");

            migrationBuilder.RenameTable(
                name: "tbl_State",
                newName: "tbl_state");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_state",
                table: "tbl_state",
                column: "StateID");

            migrationBuilder.CreateTable(
                name: "tbl_Citys",
                columns: table => new
                {
                    CityID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CityName = table.Column<string>(nullable: false),
                    StateID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Citys", x => x.CityID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_Citys");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_state",
                table: "tbl_state");

            migrationBuilder.RenameTable(
                name: "tbl_state",
                newName: "tbl_State");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_State",
                table: "tbl_State",
                column: "StateID");
        }
    }
}
